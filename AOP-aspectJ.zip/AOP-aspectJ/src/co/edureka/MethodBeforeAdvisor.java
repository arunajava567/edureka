package co.edureka;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

//Aspect
public class MethodBeforeAdvisor implements MethodBeforeAdvice {

	@Override  //Advise
	public void before(Method method, Object[] arg, Object arg2)
			throws Throwable {
		System.out.println("Here you can write code that you want to execute before method execution");
	}
	
	
}
