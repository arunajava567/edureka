package co.edureka;

//target bean 
public class SampleBean {
	
	// before   - joinpoint 
	public void actualLogicMethod(){
		
		System.out.println("In this method actual business logic is written");
	}
	
	public boolean authenticate (String password) throws Exception{
		if(password.length() < 8){
			throw new Exception("Password is too short");
		}
		else{
			return true;
		}
	}


}
