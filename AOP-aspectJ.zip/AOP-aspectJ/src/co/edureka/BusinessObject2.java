package co.edureka;

public class BusinessObject2 {
	
	public void show() {
		System.out.println(" i am in show..");
	}

}
