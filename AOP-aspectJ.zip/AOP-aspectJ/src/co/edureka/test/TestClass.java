package co.edureka.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import co.edureka.BusinessObject2;
import co.edureka.SampleBean;


public class TestClass {

	@SuppressWarnings("resource")
	public static void main(String args[])
	{
		
//		ApplicationContext context=new FileSystemXmlApplicationContext("C:\\Users\\USER\\Downloads\\Edurekha\\62_codes_v2.0\\Spring Codes\\Module 3 Code\\spring_3_1\\spring_3_1\\src\\applicationContext.xml");
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		SampleBean obj=(SampleBean)context.getBean("sampleBean");		
		obj.actualLogicMethod();
	//	SampleBean obj=(SampleBean)context.getBean("proxy");		
		obj.actualLogicMethod();
		try {
			obj.authenticate("1237876543");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//	obj.actualLogicMethod();
		//SampleBean obj=(SampleBean)context.getBean("proxy");		
		BusinessObject2 obj2=(BusinessObject2)context.getBean("businessObject2");		
		obj2.show();
	}
	
}
