package com.tcs1.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs1.model.Student;
import com.tcs1.service.StudentService;

//creating RestController
@RestController
@RequestMapping("/api")
public class StudentController 
{
//autowired the StudentService class
@Autowired
StudentService studentService;
//creating a get mapping that retrieves all the students detail from the database 
@GetMapping("/student")
private List<Student> getAllStudent() 
{
return studentService.getAllStudent();
}
//creating a get mapping that retrieves the detail of a specific student
@GetMapping("/student/{id}")
//@Produces(MediaType.APPLICATION_JSON)
private Student getStudent(@PathVariable("id") int id) 
{
return studentService.getStudentById(id);
}
//creating a delete mapping that deletes a specific student
@DeleteMapping("/student/{id}")
private void deleteStudent(@PathVariable("id") int id) 
{
studentService.delete(id);
}
//creating post mapping that post the student detail in the database
//@PostMapping(value="/student",consumes= {"application/json"})
//@Consumes(MediaType.APPLICATION_JSON)
@PostMapping("/student")
private ResponseEntity<Integer> saveStudent(@RequestBody Student student) 
{
studentService.saveOrUpdate(student);
return new ResponseEntity(student.getId(),HttpStatus.OK);
}
@PutMapping("/student")
private String updateStudent(@RequestBody Student student) {
	Student student1=new Student();
	student1.setName(student.getName());
	student1.setEmail(student.getEmail());
	student1.setAge(student.getAge());
	studentService.saveOrUpdate(student1);
	return "Updated Successfully";
}
}
