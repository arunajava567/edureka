package com.tcs.SpringBootActuatorApp.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
//@Component
public class EmployeeService {
	
	public String getemp() {
		return "Actual TCS USer from service";
	}

}
