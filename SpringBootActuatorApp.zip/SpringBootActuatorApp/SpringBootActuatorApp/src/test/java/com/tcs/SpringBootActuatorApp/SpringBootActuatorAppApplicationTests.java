package com.tcs.SpringBootActuatorApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootActuatorAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
