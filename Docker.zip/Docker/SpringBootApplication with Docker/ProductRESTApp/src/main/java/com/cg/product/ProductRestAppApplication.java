package com.cg.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductRestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductRestAppApplication.class, args);
	}

}
