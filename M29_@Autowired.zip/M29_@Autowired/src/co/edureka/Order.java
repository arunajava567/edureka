package co.edureka;

public class Order {
	
	public double amount;
	public Order() {
		amount=987898.99;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	

}
