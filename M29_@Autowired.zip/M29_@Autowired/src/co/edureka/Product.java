package co.edureka;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Scope("prototype")
public class Product  {
	
//	@Value("102")
	
	public Integer id;
	//@Value("book")
	public String name;
	
	public Order order;
	
	public Product() { id=101; name="bag";}
	
	@Autowired
	Product(Order o) {
		this.order=o;
	}

	public Integer getId() {
		return id;
	}
	//@Required
	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	
	@PostConstruct
	public void start() {
		System.out.println(" bean created...");
	}
	
	@PreDestroy
	public void destroy(){
		System.out.println(" bean is destroyed..");
	}
	

}
