package co.edureka;

public class A {

	public void aMethod(){
		System.out.println("This is aMethod of class A");
	}
	
}
