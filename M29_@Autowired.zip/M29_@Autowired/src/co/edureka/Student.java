package co.edureka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Student {
	
	Integer id;
	String name;
	//@Autowired   //field
	//@Qualifier(value="course2")
	
	Course course;

	
	//@Autowired 
	/*public Student(Integer id, String name, Course course) {
		super();
		this.id = id;
		this.name = name;
		this.course = course;
	}*/

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Course getCourse() {
		return course;
	}

	//@Autowired    setter
	public void setCourse(Course course) {
		this.course = course;
	}
	
	

}
