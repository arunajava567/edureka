package co.edureka.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import co.edureka.Account;
import co.edureka.B;
import co.edureka.BoxOffice;
import co.edureka.Product;
import co.edureka.Student;

//@Autowired  , @Value,@Required

public class TestClass {

	@SuppressWarnings("resource")
	public static void main(String args[])
	{
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		BoxOffice b=(BoxOffice)context.getBean("boxOffice");
		b.currentlyPlaying();
		
		Account a=(Account)context.getBean("account");
		System.out.println(a.getName());
		context.close();
	/*	B b=(B)context.getBean("bBean");
		b.bMethod();
		b.getA().aMethod();
		*/
		
	//	Product p=(Product)context.getBean("product");
	//	p.setId(101);
	//	p.setName("abc");
		
		//System.out.println(p.getId()+"  "+p.getName()+"  "+p.getOrder().getAmount());
		
	/*	Student s=(Student)context.getBean("student");
		System.out.println(s.getName()+"  "+s.getId());//+"  "+s.getCourse().getDuration());
		context.close();*/
	}
	
}
