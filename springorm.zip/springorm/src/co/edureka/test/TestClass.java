package co.edureka.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import co.edureka.bean.Course;
import co.edureka.dao.CourseDAO;


public class TestClass {

	@SuppressWarnings("resource")
	public static void main(String args[])
	{
		
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		CourseDAO courseDAO=(CourseDAO)context.getBean("courseDAO");	
		Course course=new Course(94786,"Neo4j Database",17999);
		Course courseNew=new Course(94786,"Neo4j Database",10000);
		courseDAO.saveCourse(course);
		
		courseDAO.updateCourse(courseNew);
	}
	
}
