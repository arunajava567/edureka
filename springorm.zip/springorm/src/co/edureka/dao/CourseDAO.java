package co.edureka.dao;


import org.springframework.orm.hibernate3.HibernateTemplate;

import co.edureka.bean.Course;

public class CourseDAO {
    
	private HibernateTemplate hibernateTemplate; 
    
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate){
    	this.hibernateTemplate=hibernateTemplate;
    }
	
    public void saveCourse(Course course) {	
		
		hibernateTemplate.save(course) ;	
		System.out.println("Course Added successfully");
	}
    
    public void updateCourse(Course course){
    	hibernateTemplate.update(course) ;	
		System.out.println("Course Updated successfully");
    }
    
    public void deleteCourse(Course course){
    	hibernateTemplate.delete(course) ;	
		System.out.println("Course Deleted successfully");
    }
	
}
