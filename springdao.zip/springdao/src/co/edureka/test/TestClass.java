package co.edureka.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import co.edureka.Course;
import co.edureka.dao.CourseDAO;



public class TestClass {

	@SuppressWarnings("resource")
	public static void main(String args[])
	{
		
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		CourseDAO courseDAO=(CourseDAO)context.getBean("courseDAO");	
		Course course=new Course("SpringbootFramework","Actuator",12);
		courseDAO.insertCourse(course);
		
		
	}
	
}
