package co.edureka;

public class Hostel {
	String hostelName;
	String city;
	
	public Hostel(){}

	public String getHostelName() {
		return hostelName;
	}

	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	};
	
	
		
	
}
