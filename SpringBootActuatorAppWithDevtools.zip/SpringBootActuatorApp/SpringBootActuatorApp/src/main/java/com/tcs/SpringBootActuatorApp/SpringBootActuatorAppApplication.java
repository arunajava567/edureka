package com.tcs.SpringBootActuatorApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
//@SpringBootConfiguration
//@EnableAutoConfiguration
//@ComponentScan
public class SpringBootActuatorAppApplication {

	public static void main(String[] args) {
		//ConfigurableApplicationContext context=
	SpringApplication.run(SpringBootActuatorAppApplication.class, args);
	
	//SpringApplication.BANNER_LOCATION_PROPERTY
		/*
		 * int beanCount=context.getBeanDefinitionCount();
		 * System.out.println("=============:"+beanCount); String
		 * names[]=context.getBeanDefinitionNames(); for(String name:names)
		 * System.out.println(name);
		 */
	}

}
//com.tcs
//com.tcs.controller
//com.tcs.dao
//com.tcs.entity
//com.tcs.service
//com.tcs.xyz.... spring boot cannot initialize your components