package com.tcs.SpringBootActuatorApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.SpringBootActuatorApp.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	@Autowired   //byName
	EmployeeService employeeService;//DI by IOC
	
	@RequestMapping("/get123456")
	public String getempName() {
		//EmployeeService service=new EmployeeService();
		return employeeService.getemp();
	}

}
